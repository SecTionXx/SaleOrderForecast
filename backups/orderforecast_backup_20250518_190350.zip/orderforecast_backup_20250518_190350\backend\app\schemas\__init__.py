"""
Pydantic schemas for SaleOrderForecast.
"""
