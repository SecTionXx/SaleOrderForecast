"""
API v1 module for SaleOrderForecast.
"""
