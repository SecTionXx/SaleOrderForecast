"""
SaleOrderForecast FastAPI backend application.
"""
