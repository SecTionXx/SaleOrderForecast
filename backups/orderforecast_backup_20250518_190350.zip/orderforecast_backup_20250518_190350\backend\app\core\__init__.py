"""
Core module for SaleOrderForecast.
"""
