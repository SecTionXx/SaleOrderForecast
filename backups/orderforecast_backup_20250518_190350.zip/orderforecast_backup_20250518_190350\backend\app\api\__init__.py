"""
API module for SaleOrderForecast.
"""
