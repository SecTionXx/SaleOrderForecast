"""
API v1 endpoints for SaleOrderForecast.
"""
